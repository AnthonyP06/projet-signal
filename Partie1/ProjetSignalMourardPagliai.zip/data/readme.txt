Nom de fichiers : 
LA1 d�signe la note LA1 accord�e .
LA1_p50 d�signe la note LA1 d�sacord�e au quart de ton au dessous.
LA1_m50 d�signe la note LA1 d�sacord�e au quart de ton en dessous.
