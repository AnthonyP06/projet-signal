%3UNIDRND Tirage al�atoires de 3 �chantillons.
%   Tirage de trois nombres al�atoires suivant une loi discrete uniforme
%   sur l'intervalle (1:100).

clear all

x = unidrnd(100,3,1);