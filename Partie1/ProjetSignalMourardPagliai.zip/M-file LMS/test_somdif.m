%TEST_SOMDIF Somme et difference de deux matrices.
% Blabla 

% 2013-05-06 S. Bidon


clear all
clc

%% Matrices a sommer 
N = 4;      % dimension des matrices
A = ones(N);
B = eye(N);

%% Somme et diff
S = A+B;
D = A-B;

%% Affichage des resultats
fprintf('La somme est :\n')
disp(S)
fprintf('La difference est : \n')
disp(D)