%PC1  Quelques exemples pour les etudiants.
%

%   07-11-26|creation|S.Bidon

clear                                       % efface la memoire
clc                                         % efface la command window
close all                                   % ferme toutes les figures

%% Calcul matriciel
phi = pi/4;                                 % [rad]
A = [cos(phi) -sin(phi);sin(phi) cos(phi)]; % matrice de rotation
disp(A);
iA = inv(A);                                % inverse d'une matrices
disp(iA);                                   % affiche le r�sultat


%% Jouer un son
clear phi A iA                              % efface les variables 
clc

load handel                                % charger un MAT-file
sound(y,Fs)                                % jouer un vecteur son


%% Traiter des images
clear y Fs

A = imread('lapin.bmp');                    % retourne l'image ds 1 matrice 3D
image(A)                                    % affiche l'image


%% Jouer un film ["doc movie"]
clear all,
close all

Z = peaks;                                  % sample functions of two variables
surf(Z);                                    % create surface
axis tight                                  % control axis scaling ["help axis"]
set(gca,'nextplot','replacechildren');      % ...
% Record the movie
for j = 1:20 
    surf(sin(2*pi*j/20)*Z,Z)                % create surface  
    F(j) = getframe;                        % capture the figure
end
% Play the movie twenty times
movie(F,5) 


