%INT_EXP Int�gration num�rique de la fonction exponentielle.
%   Compare la valeur d'int�gration numerique de la fonction exponentielle
%   avec sa valeur th�orique.
%   L'int�gration est realis�e entre X_MIN et X_MAX.


%   00-00-2009 | Modif | Nom auteur

clear all
clc
close all

% Parametres
%--------------------------------------------------------------------------

xmin = 0;                   % borne inf d'integration
tab_xmax = 1 + (0:2:20);    % bornes sup d'integration
L_xmax = length(tab_xmax);	% nombre de bornes sup     

% Integration 
%--------------------------------------------------------------------------

% Integration numerique
iexp_n = zeros(1,L_xmax);    % pre-allocation 

for ell = 1:L_xmax    
    x_max = tab_xmax(ell);
    iexp_n(ell) = quad(@exp,xmin,x_max);
end

% Integration theorique
iexp_th = exp(tab_xmax)- exp(xmin);


% Comparaison graphique
figure
plot(tab_xmax,iexp_n,'b+--',....
    tab_xmax,iexp_th,'ro-.')
xlabel('Borne superieure d''int�gration x_{max}','FontSize',14),
ylabel('[-]','FontSize',14)
title(sprintf('Int�gration de l''exponentielle entre x_{min}=%.f et x_{max}',...
    xmin),'FontSize',14)
legend('num�rique','th�orique','Location','NorthWest')

print('-depsc2','int_exp')
print('-dpng','int_exp')