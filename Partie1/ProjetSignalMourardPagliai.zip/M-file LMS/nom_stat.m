%NOM_STAT  Statistique sur les lettres des noms de la promo des 1A.
%   Le script  a pour but d'afficher la frequence d'apparition de chacune
%   des lettres de l'alphabet dans la liste des noms de la promotion 1A
%   2008 ecrite dans un fichier excel.
%
%   REMARQUE
%   Les lettres accentuees sont assimilees avec leur lettre correspondante
%   non accentuee.
%   Les lettres les plus presentes dans la langue francaise sont dans
%   l'ordre : E, S, A, I, etc. 

%   Date | Auteur

clear all
clc
close all


% Lire le fichier EXCEL contenant les noms-prenoms de la promo
[num,txt] = xlsread('1A-2010.xls');

% Creer une variable pour les noms de la promo
nom = txt(:,1);                         % nom eleve

% Forcer la variable nom a etre un tableau de caractere
nom = char(nom);

% Vectoriser la matrice
nom = nom(:);

% Supprimer les espaces (' ') dans la matrice nom
nom = nom((nom~=char(32))); 

% Supprimer les tirets ('-') dans les noms
nom = nom((nom~=char(45))); 

% Enleve les accents des caractres accentues
nom((nom==char(200) | nom==char(201) | nom==char(202) )) = 'E';

% Convertir chaque lettre en son numero ASCII
nom = nom + 0;                          % autre methode envisageable avec sprintf.m

% Statistique
lettre = 64+(1:26);                     % les 26 lettres de l'alphabet en ASCII
[freq,lettreout] = hist(nom,lettre);    % compte les frequences d'apparition

% Representation graphique
figure
bar((lettreout),freq/length(nom)*100)           % representation en pourcentage
set(gca,'XTick',lettreout)                      % force les valeurs sur les abscisses 
set(gca,'XTickLabel',cellstr(char(lettreout).'))% force les etiquettes sur les abscisses
ylabel('%')
title('Frequence d''apparition des lettres de A � Z pour les noms de la promotion 66')

if 0
print('-depsc2','nom_stat_2010');
print('-dpng','nom_stat_2010');
end